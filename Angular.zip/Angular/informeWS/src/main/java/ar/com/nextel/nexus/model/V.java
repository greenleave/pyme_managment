package ar.com.nextel.nexus.model;

public class V {
	private String v;

	public String getV() {
		return v;
	}

	public void setV(String v) {
		this.v = v;
	}
	
	@Override
	public String toString() {
		return "v:" + v;
	}
	
}
