var app = angular.module('ReporteApp', ['googlechart']);
