package com.javacodegeeks.examples.realtimeapp.part1.domain;

public enum TaskStatus {
	IDLE,
	RUNNING,
	SUCCESS;
}
